## malloc/free ##

### 一、VC6内存分配 ###

![](https://i.imgur.com/GSff1Jp.png)

![](https://i.imgur.com/EZG35WQ.png)

